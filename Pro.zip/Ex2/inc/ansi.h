

/* Exported functions ------------------------------------------------------- */
void fgcolor(int foreground);
void bgcolor(int background);
void color(int foreground, int background);
void resetbgcolor();
